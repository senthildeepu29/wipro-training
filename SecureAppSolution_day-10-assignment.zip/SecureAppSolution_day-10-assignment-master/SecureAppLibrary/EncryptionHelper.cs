﻿using System.Security.Cryptography;
using System.Text;

namespace SecureAppLibrary
{
    public static class EncryptionHelper
    {
        private static readonly byte[] key = Encoding.UTF8.GetBytes("1234567890123456"); // 16 bytes for AES
        private static readonly byte[] iv = Encoding.UTF8.GetBytes("6543210987654321"); // 16 bytes

        public static string Encrypt(string data)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                ICryptoTransform encryptor = aes.CreateEncryptor();
                byte[] inputBytes = Encoding.UTF8.GetBytes(data);
                byte[] encrypted = encryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
                return Convert.ToBase64String(encrypted);
            }
        }

        public static string Decrypt(string encryptedData)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                ICryptoTransform decryptor = aes.CreateDecryptor();
                byte[] inputBytes = Convert.FromBase64String(encryptedData);
                byte[] decrypted = decryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
                return Encoding.UTF8.GetString(decrypted);
            }
        }
    }
}
