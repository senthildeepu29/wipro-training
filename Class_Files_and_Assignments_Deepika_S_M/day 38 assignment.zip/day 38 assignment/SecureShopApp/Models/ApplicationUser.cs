using Microsoft.AspNetCore.Identity;

namespace SecureShopApp.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Extend if needed
    }
}
