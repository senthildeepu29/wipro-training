using Microsoft.EntityFrameworkCore;
using ShopForHome.Api.Models;

namespace ShopForHome.Api.Data
{
    public class ShopContext : DbContext
    {
        public ShopContext(DbContextOptions<ShopContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<WishlistItem> WishlistItems { get; set; }
        public DbSet<Coupon> Coupons { get; set; }
        public DbSet<UserCoupon> UserCoupons { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.ConfigureWarnings(w => w.Ignore(Microsoft.EntityFrameworkCore.Diagnostics.RelationalEventId.PendingModelChangesWarning));
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasData(
    new User
    {
        Id = 1,
        FullName = "Admin User",
        Email = "admin@shop.com",
        PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@123"), // ✅ hash password
        Role = "Admin"
    }
);


            // ✅ Order → OrderItem relationship
            modelBuilder.Entity<Order>()
                .HasMany(o => o.Items)
                .WithOne()
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            // ✅ Seeding Products
            modelBuilder.Entity<Product>().HasData(
    new Product {
        Id = 6,
        Name = "Wall Arts",
        Price = 6000,
        Rating = 4.8M,
        Category = "arts",
        Stock = 500,
        ImageUrl = "data:image/webp;base64,UklGRgofAABXRUJQVlA4IP4eAADwewCdASrnAOoAPp1EnEolo6KkqNhMGLATiWJsWXz6h/t5/IKJ/Z9Gbwzn3eWHP+IX9Besjl/2z/O/vXpe8t+GT6ncp2H5mr7/+69av9c9Qr+49GHzSebz6Xv8J6Y/VB/2T1OemK/weEj+UCyV1MikfTWR3bv7Xfm+oyOEfdTMf/M80/EA8vf/D4q33X/u+wB/N/7d/5/aN/2PI9+yf8T2EPLg///uO/c///+6X+wH//P7d6QYebXfnCiOs49abpfKePO6nUeUp3OT4hNo3CceZh8R4lHX90iGGRltAAapGxw9lTYBqLQOBlnbL3ulvmUkeVa9rtds+8He08MGsnlgKx6QcaJ/zAvGB9eCAoMgMMdzFITLR5fKxAVyxSsiKbPuY68V2jcmAUuX4ZKrSJ7HNDhgIRe2+h5wU1Wgc0deNcdjsL6ep9ogbiW9LElUdGIxgmllFcWkixKzSr5cZRD40KN76PSBbLZhypZQ5ddd8Uhh5ysWaZgPWvVI61z5usVOYo8Fi1qc54pBwHzd8fxkC6xx8ndlDucS1Qblg+F70ubozvrlkQgkQveujRiVHnLBVQAt013/6qmy9gHSlIf9FnFUOov3JWZqGw6IrE78mRfKvijat0Ki8E0N24rCaNiyB/pBEYVftOSwvD0WN18IcBn3OIGHcRkVMD7pKwQ1cJc5pn88T4ABahG9kyEGL9BxwLOU9YasKoPs+zrpWQMuKjsZ2bsYA1wtFLWbXFlYBi2Ju06FikT11+Pu8EiHF3OBSesR9SiJX6Jl5jfcG28JVrFQjH/C3bYqi9yvBqK3CY+ntyTzGHuhBDZRWA4O+VbMMYXW+aedVcChGHOBH4as2fg5oRKd8fFRFaGQMcwurUkiNq/hAtneIT1/9eaiNFPMsjy1zNDCkQ8nP23duReZRVhjf8Hnxnczfy9Qd6s20eayhhGiW7UcNFNr9hlnze2Afnho63daKMBl+8QAv6zKk/Gb79XlL4UdsFSeswOFjNh+hbE2ct5UPxNLygvAchYanp8W6xd4XFA2cC1AuxjcuWa+7hFsDK62yo5LuAdOVa99WL69JNkotcMDmmVjzItGMjBki2AUFWrSqG/tW9fD1V8LE8bUu8nyuhXXZHd6RvS5D0XNFTE0J+thTjUu+pHJVapm1d6uw3XaVoWB7xp1EV0pYmp7b6d97wRZp7+oNLkxZqZEXR+6xPI/nnbMGBNiPfbPJ5PUdCnSAEWuM7YGsUcJJynlUz1q9p/zPyVPasrNKtZ3s7v0F1g6tlq3gxRVSMENiDuRJThfVllGK0pDex9+2xMOBoD3oIZ8J2u6oIQeBnc/pYUAAP74vIl42bok2mkNEQKQGBSsCRlLgltWHbogYj3i4HL6GeMd78/xJwfZVghnZIbi/R+Kclh1i1qQZbbEK3fAXivabobT5I3+pfSBZETZVjmhLrHBe73Py2FCke0Rietu57jrHWbgAlTaYaaUpEyp97xf82gFXWztucyAPW0E+/ohIJlklba71MAyCTfpneW6bLjK+rrnA8b/gLddOayA/NZEHlIrriLvmBlWPGjaFhG6FUQSL1RzkxVyx98Z33+j6vkFUsfSGoyD8kcRhqIhCKUYv3V3Vam6GdPadIEGSCaXiq1B/ds9Cg2PUKKrYEn/S0nzp62qgDNEbyoUAUT4MXlLWGpSjCgclAwRTrtrjW275J/4LYYJhi7CgRsX7faNo8DbzGaHMaREEjiv5S1pbkzCrsrKxu6epSnPkT2c3B69JxLx6cSDD7zUzFVEcTrjgoWaHBje1o4cgy5dZLkTibM82Lc8jzvwF2o7kzjvipOYfNhoRBIa/t1c/9DbMtU7vYapQANgyF7kVHMQ7JiB3ly4hWraqann/xlZTmW7fT6IRBPZ7nkHdQ/xQcwiHaXcHrXjJgnQoFae/36BfvzHqLwDq/zPDEfYD+v/T/5zJbwEMfL3JjQMRrc+s0MpdNEpeZymE7CUfhn4cAi6t/OtWNYLuCQJzxUVY6L+Y10SiU6hOLFG6x73DnjNDCOdRkwuXWuSS3bUVfQNgDxhovRn5VPtj6yt5zNsMUnOM9bY8AhxGTQ6JN48JsAmeQuafuDV0pj3pO4enow2uQTC3MTqs5lBb5YxBCJAUlztSyUyEIp2wDkWXU7TOaT1q1hiMNXHqWBH+miJV4aAbpQmuY113OpVraTFp8B4iaNd0L7fRJbUFPV6cwnHn8+24fNgb2YY7TiI3BJobzc7jz+8PBBiUKY7xdUdtCLwPDfgU372FVF9iXC0aWr8WkRnQmUQQpkoIsIZMMWscWWy9vA+pRsJ98fc9yMXIA1x71Ij0fiXilTLPBj+EnNfrIB+6CKS4d4zUaD1BpVarOteGT6R+myQLv/MLGaqWRjJ4dDV3MU3ItcJBSfztaeOSOYcm+Ggg95RIXr3cvvd3SAJgOd066V5a4lRIqoA5iezaoMAeTIgFjeOfrOuJ81yMsIm8CFa7G8Wuq572Yydd38xKMLnJHYzsT4AUgcjBnLZbYb9gJmVnnGY5SbnjEIE2bp1dFzzMKzcWGY5cluYfc89+m8EwO/N/54l92pIuWVQ9JkCyi84DkOFUvHh+7hv7faBVLSXqRxGxy7s+WbcvZSDh+0MTHtVy5NRqnuCtTHklhga5daGRra/jeDYpo0EUOQEjbizob+8L4TBj5uSp7xCzNKgkY6mTs3O9TrehK0VrpAEthta4FblNkbO4sAaKcbyh62f98k+XaylIvQuxXrG+lvgMc4E44P9fuqEFGQRRFQAflcz8yJpkrALDp02+S6dYJ6ao9mUWJnz+t0Jc8T4oFag7mC/v9eR7djd1bitGejj0NXmCb5CiBNMMbBDoWlyV+4hvswaDQjmknouKdIS21huo9vBkGfX1qQASq38Rr7o6MRfjvr6bC6N0qpWsVcCJmTu/WdQYuulnWxagk8AjT3oYHEGrv8OCoUsob06pXhgUx9CUU6krg+AbFBdCi9SQUNPfZrNuhaNlrfuIoE6XijLv9y+hUqezdkIegnkLyfuUX8xS/zJapKQJF9I2ID8uWViUPhjVzycd9+XkHLvUU/lRRMpfYD9fQS28TVYgjm7ogFtNXe4q6KYyhIR1sl5EAAb1sRf456HquV9Ic59m2Obh4UfEeo9L1UW7DaLYBi3tn94HfHNRu1s+7Zrpz9qkD4E9eixytMCh6Vt/nBVzePs+SCWhocblD//TY3iq6rQa3M9i0saAwd6FoAMSqi3drFI0ODnhOse1EvKxfvqqjgJ5m2TxeE2ZRuHKQnYB2L584X3jnAo7SXGnRopiN7K/CE5p7hULHR/Vuh9C5RJciQYQzPDOe4ES4ld14d5tiJccWYlOAIVgfe9KKFs9BkWTY/Dbyhx3FtMo4uHzT2bbfB9O+yk3wKP7thwghR57kP9y9lB7LB2bP0rPdg6GXR3m5Pc6RhnZGqRigqkRtlufT7q5z/YjfqL0BPd9NmpWToNsGP1ZC0n0GXkr4J34+hdm8uCgaZBdgGOVFhPIbu6o7aknbyusXzet008j3MgfL6ZqasXFdlF5fGGuvHpBveljXisV20NrZTDPrVXy1a5gPAvdhByJi3uTbh44regtXQzJWCv0M4JIS7DTaMwf+QmGXmulpbcVzJ2zdZoxM8Pnuy0Ht610HsBPF3fYdkngbHkTPk1eSjggKmURormzLRY+BIbBjsvQaeOHy9TJ/vsGr06mvUxNkNHBilqjYBbo8FYfBpgR4cgZrP2JFRPsEQ0zzrCYJ6eGeUHcffu4H3gjLQt1saKSiA0aATlT3E2pC1YoqSoqnle2o7o4jpaqLOX9kOQ24tRrEIEkF+K/1jCOxiGFAxYQk8VVLhyC/uJR5QDV0XWvEr/J2KKlfAc5x/Q8a7V+v950BB8YjtTsVoy0l+obGIKRxhtl8If6WYciJvtt+Y+ZS37gfOMryUiDbGGXYlFe/Ic55Spq913G2PYt7N0vKeU6Wpon0AuVepu0G2L6YLXQvfhyalnuOTBSXsxXnTUWl0f6QrQasZ7/M/MBeXUX5F10sBXDjY9JD7um/oiiincALLDv1UH0DYJ/mkKqYHb5wN/U10cXetj2ePJapTZFr+bX6ITibMMFBEzikW+i+zsTQF7cdAhrCSucAvJtE89sEcJJtNdAHoKLzVlBAgiYFF716aLmxQJUXXI43LE+yMkVzNZ4TUpjpzqT+rPQ/PO26OQ8NAkMq9SMHDQsKsfW8rerWxN0jsriAGdx4rmooSBu7wgjc7zFXkyX3zM00f8hoRZjzYcfHllE1++LOeoiTr0fsQYDvF5+J/+dqixnyTrZo3zbq071DzA6sjABNd1AwYTy67AVPkLxiWidOv1GB+6pVT1Xcq7HcTrRgSkTs/OVu5vShDXdcvZEcYLNrgBua09wNj9NA/xAUVr3JH+ypTX4Quv9VXESLk3kTRJUkF2ySXR5qXdPw4LefOMYGK7098MOOyqL0dhh4D6UzsY8xq9H+uZ3LIXqswXXtm1+RGSXoezMPOQSAt9n2ydVpjxSZyv/91rrAqWRj6xk/twwqjIx4PGZlcEWO4n9RBFQITnAekcWHb1qA4Nsw/U95DU+F4WFsaAfrA4GQ6O0SOk50Po1+QBAOOkCzw4bzGF7ICRii8etsiIRM7u8mW0Vz7zyZbvXqGpb7ZwCMMoMNnYuQ8inj3JgI2O00vct/LG4JvkIqlM0ecFAGk0qpGoLgK+VwdM2yUuQ09GeMykLkHb+Hp8usFxzN4VxihoS6J2K/B525kEKWnSGOmQAOpitoFakUvSyQ4plmaFeufqzqCTZCjhLdTE/gqWujC5DwabN2fq1awEJEk5itq66w55iyqliHJzv1WxCe8sgmqYZ4b9xvtpqHCMvEDLVJShTRTg2G1pQzZQ4OBQ6fYIAecVbujfcKDqeGtBHusjg3BYKop5ut+IRAeWT2VH9g0XTw8R0EOAN+T5SW1k7yTXcfezWAwiyKI+nOp8BGIuvQlAhz6JAbHov68P2ZAlZ6UakVVe2Y2lwMEFpXIVZ6jQHZzlbDS5Jbr14IapYrEE4q8uTELDCOQmdEt0G1RSRGXJsrvI3uDwjjvA4v9lzXk2UhKlBw5In+mb/2FIqcqphPIb5oVN3vCaI6vH/0lICV86nLHuNSrEkpCXKrAw1ey1zyYwQCmsL7QS1WHNPWocqq5VQqrivSj7/MCxHpXFj4rbEqJEyvwC1O0HxNF/xRaSr1jiTdcIzzRgCTUK9j5CnYV366dBc4l8MQMjqgQfGXK2zUCtKlgUFz5bOEGBJLFCXEWbX1jjBacPxtTCnPMj8uNKpfwnQRImFev45zXPrTFGmZdYaQcIDcje/5XGQsXtwnB2NMnxxh2gezaadz4R3hcNkJQSJEXuymXPx5fbTd0TyWrVgfypUbY1blQOK8dakALzV2e+bcCep25G8FQpNU9GT7HtcUgNxzL1eZN1/ClfEm58i8e7zgiDzTdKmweZYA3p2/7pt0tOOXc4Yz/su05y72vpBUIk1lAzdYp8kpWi3OEh2Kw4Gr3OLdJd5IUpvlZfDZhG0Qm99rOBxGkTVnWxVbS1cRBtIc8IClNQ07tUEdIqYrDgAM0YOMQa4S4Rrq+Ir+qyNW3DO3Z9ndc98fHAsH4V3OddE2utv5eFcIC4obKvaNasqX8BKUuBeXV5n4R8ssz2dsLAeLPl80tMtU3BeCvcN9vOYkB7XwtC7DwPJgYAfTgWdeLk2Qh3m2/lO2fBnZQZzTY1Qf+lAxVvLDh7GJwnyctqMcteZwIZ8pcymTIal4GXTOxsKqUK63+lSlKGdE2FKEWQizUYCDp5yv2FvxAJKI93txfUrLI5oVA3XQfFvYP6zLqtFPa87I/YQXLOoSvNrVtNxHKO11bbiTvxovN7yQir/UjGP4o6Xht3TnhRIWVpmKoOEiFi9YH7LGdrqOUE7v9qG07m0Pi9PXQMVomWd+L/bCv8TVBAEPwpkI0Enp/QjNs45IOXCzWZtAhYkev4mfNRDQw8omtoC3DDQmPdQEeJkBy+MWrxRyN2UZVZES8cleEkPoafjSaiaNP3Sa7vCJnXsDF3AeeRD0HasLxelSkwaUymUCQfL7atReqMHndFA/KmuMBpg/qDrJe3SRsY03ibZ7qBBaCgwpTgPTXBwim/EblFt0hgAtE1wpoiBUiBzmBIkicEkxfMafwflSchscru2UloTALJJBZnQ7h9gTxl14xIDb3pV8uHJJuX5BUAa1T6a/IvDHMBhyk86J5gw/liYCPNaiXfbZJOmS1LwLAGbV64XRh/GegmnSDFD6cR5+6jaw1108o5T3V4S6KeB9wonV4Sl6nxDL9iFmCxmkTiiRvBvzJEPj/PqE+jMEZWO5pI4Lb3p5mHFizYZt0nfUpKPq89lYQ8f4hb6PHHEb0mjKcZtpHDi1iamuWIrgA7EJYsKOb0grkUWGZ28fGt4nDrfSGqpTWltw0zBrC4yIYzKECZMm/rF8MZsa7sMib93cMpUgzhM5rGFEpuPIikQ8ytrutY6aqTjMm11+FJdsYRxICpGBTbojCRxajeb/a5gLPG1eoNc6oJn1CyIWEZoEGVmGSq8MpfcYnxLB+GfAAi4+DR3NzCTCIxM4gEU1WRzJ1iUk1OQ1lAFyUcBNwJTvFwsidZooXgd+36zy3Uaa8xbEWIJZvOLubGNq52YmE7zAcmasoA0t9mk5wT/qnvKEd04IJm+02xpRh8OZSJ8316H4z+ZClALwWf/xSVjvDsrju6UHMR6jzljCv9kxjVPc8TPr4TAthvRkW9r7iu1C8j+VVKJXddnvuNfHhhC6tpPirWzO68sOFmx9cFJju4hEAAC4aV9YOzAq0CozT0PZQOx8mlmVueAE8ml0+dKt/4gRvvl1qgHWN2PO694evS1euUsiFfcj9qDAV6FWrD5kKtFoFsDi6J65OVtiJY+FZCWCF7xKLzQDK4SkHqXDE1TaA6u1Q23byCAOwcL+Iv7mZQMcDly/v5GsVS813aAOzXw3PWe+TXXV1UMA7BlGqd7gaZA09sUNn37Y5MK8O+z7yLwLA4fqecqDF0rxa8xx2pFoJwsThwB3CrDN0bV/wtILP4XZFwbotT3+wNsnkI2m4Fnpb0p+9A7NIbj3r+RvkLZtejyO530hTWIdq2mg6J8PvC23RfG8y4lqnwnxWUEXdOi2NQuqsDXn/LCs3Vjm2RHEk0Vgl5yVLomudUKgunPudwI9di58520XenvdvEJR6PwxgWQ5Jd9GXTQwWEGqCzpuuDvqCy+k+m3rXtt2YLSksbh2YAq7GmK/WhPoX1vxeNzoOpFke8or8t1U4vqmiOiYXFDZHXtLQYO0BGhfj0ZOWbNz7E2WcpIj2lUr9YorJaT5al6kbnanYD4UUCxYCCFRXFElIvBc69jmUKGqYDUQo7jer1oIfVbcqySodlBdnu+cA29CZoOKEvkFwAYrdGInt7qOYafn+bTxHW7A/IrOyaPep6UwRsAvaM7MPpCf8lFzfQa/QDppuxEQOEz1d4c54UXV7z14cS1ErHVEWIVbMsiv5/u4morEwC4mbKea8Onfe3mm0u6VRYUdIQMVAX9ssJTC5maKsw2EjWxmNJbbJvhL0fjN3s73Rht6OJGB0hOXXBDGMys5utiox8emtZ0BUTpObr8gOBC77gy6ymLycSFYD5K6rXKjP3k85ujWhuUvOGbv2ctmP66rb/35qwtiXJJ46z4/gyhAJ3osMeQAE+LHimUXOePXgGELIzv2E2noz+MERuUAxzwJe1bHoAyMiMcXsLGTIIqmVrgwUdca8eLaNzMxuxuc63sNW3y76lWm4HEUJKe0bDB3atlslzJcm599U5Ys5mvQ1053PhXMFbJgF7LLn77VTvxLzVC9dOZuiCH9t/YmAURD+XU0nT1WG0jmfxfEyKu3o6AA8U/uJDuWipwxyLSKP7CJ/PkamM226pH3hjAYz0L5B6SFZFW3gWFfAxWdb6IuVmDVj7oPhCXKZMzr5cTbvf5/+HU+l7z9YIk4xDgVDZwzSaymWaodg4YoI5+Ss996x4lKyDXtgII/1tIElS8HTDXdDWfDrem4JalQ7pftcGg1+8m2AQwZRku+iz6X8I8WlVs+Ms67f/bbSISfa+WVdLK+s2A0mYe+UPC929HaX8EM53Pw/z0xSK7hSTBiY0XZhdHIJ+25m/F+GkW4uLwCur/IsBK3w2t6Pdm3/PpslSbVDGWlRpCBaByaLtU6USEDWzm35oNJLAE5Q10Lw3zgCFGGw6CnLTKW9zlhsOvTY3slL+li6NixzR41iyPf+jjva8lHyrLVjGzefSrr7AD7uBPc76Tnza1QOUj5KqcL8i+lqhqkxTO9j1WiYLzMwbJQSzTkfawYC4s7b7ncAkyfhMyG8qACseZ7EvPKzHjzmy0MruXbpIdnrM0oRijlvetDiEfqIUVQvLINYOcKc5TIIfHwBCilgfyFYYDmoqEcuKVWSNpkGKkcFA1pxX0FqgS4nkz/QWhjrXSBHYYG5rL/B/mM23I6wZj4VK1fsDc6iNLBQPrf2kfBwcxCsmnHO0OceCE9arsXliiR/8hgK7GzVcIRjkcCzYAn/s+KZulD3uUX6NrEjWYCJydxp3EdX0LubZ9BapFl1CvKkW1/Q7y4O4h1/zsBJvMfkyIQ1qEMwvCl7M2/CdfVyVrDXc6fNnnvsBleI238QW9GfeG8715GfTAqE6GuAdigb2WAQP/DAcwwsxh0CGjBJBW9TslLj0hlNE/hHY7Qdk+V6n9mXirHOdqlA4UmLYsAnpB3ZbpwAX6VC91SrvXm5BE6SxtHU8ZRDqe24PJ8Cwmws6Y8RrU5k9OYS9URtEh734u+mXSOpKrrHFL+MHE0aCBLZTlRa44dyCjg79iW5Se+Rfodz6jyByX5ZJn7D1rLJF9LDSf/LtlSayUkkuWD8Hc5yWqd+fyEo8dx0uxCZH/k0jPSNYABjDiaLB2JdsqrIs1uur8ZvPClrzPORR6pN6VI5SviRfdNvyhBpNGHDQWaggJZudT2iU4PZjXfG+Jjh7JZR85a1HZB1nAPShyQUPqRQTfhzbmF5zxVsk3Id98Gg6byBT5ZGau089+oePNrwo6jWi5IotRpPoER59YJoqX6m5L1wn3vUHH/bzB//CrdHLocUVDqVvPXxynFhKlwoV+ZZsueu34NK6Btk0nBPoit6HJPQpxr1DfOUl88MKeuCi58RBXokVH7vk9TMwVFe+ZXtXEj0QubgaDqaBKYwlDauooQAez9mAXZHrBFqyuL8dKpFmg1EFLdlBLG8tV917MEcwwaSCnHdMgejZ/mSINJsNdSzmYbY6lZwIAPZuoXem6jcF0UOf9ZMOarC5NEHCuRSZ1k/huEQDMAH0rsEyFp8JvTIS8NsSLNuOTJLY1oHv3EyokvBsLcOTJF/jJXWyoGjGMZ79ZxG36l4rlpJij0D8S4+x+jlCKC+FIgNWtEMtHFXHm40Q6Yk+1X7uLAn2iInx5lqhLqsBo9Ae6BaywxO34U/bHXlTqGj0QrNwinDU1oGxi1F4lNygaoPx2W9XG21RBddPuIsBmGwU3fMg5vQJsTITMktEJJwonxMJ39kTNLj1hMo6e7Sshgp4Tt/HDNIcNn7YkqmvbOJQIGuqlwRhiZIhDWrKX5BXEGj7EZlnKFhycmQDntk53SwNzRHwYVe5PN+P0kERv+Mq8BmnjidI7PhoI2hWIiiKnSJNTSCICcQsnSxBy06ZB3xRuPdVeXWB1ykLSlGNL5cpjSU+mbCDQyPTCsVYG1ubPtkIPtZiGC32gAVXaxc0Hy/cq028d/WxuFpPsy1bgJZjKQEqKjxslp0eb7XIxiCuJNXEF1nGtdHIgYnD50I9xTCMQAzCRNykIvWhytP2/gfGoFZfoYdVV9tMH6PdxEwQFWZqGoxIJuKIuKG87bNkVcTpYPLufkiAAw23T7PvRfrAwig++tfK9Jp36np+w9JQngOgCVJW6n5mnwiPLjJ+h2mJ2u7vrOFF/af/umVubLEvgmSKw47vjc8K5ZI9uudfqnSAe82wpSoWsa7W0KPvVpCo7Hh1FAWwvshoPH4RK3prljBLBLsSMGGPl4uK8C/yZjZH0SEuULoDmvxWhNl7jXMaBx799+USb5TYXBfg1wczp1HXgIx8dTMjvvEXEuHaDl7iEeETqa/x5aVl6KPcNODeC7xjro+Ce1KPnjcfo4/MwSVZxNKc1/IewDMNdbpUW6vkQJFnhcBTUzEdnKwtorKFTrcRcaB3/AwH7RhzVVDYIsjTYjJQxfV8I/zZ7YT0QlxgaQ7Jv+yMpuefo/21eX+87UiD++TC/r9O2ZYfJzIkh3pp92tZ3NSMsFBl4z+LBGuTrBqCfhliPYC0qq7Ls/X0+MI0JUNLpr27L05kaJCVLGbht6kYlbHazqpLHgqH0nkbBETg7sjhKjrwozuQtyUoc6A+OBeP249wP8GFhL+zAngh3bl0/BIPSUhPQ2Pdlt4+Vx+5vV9PtYAKO8jBDoYJOXAyrEPZUFZX//pOkmifzy3EOSWyOCi4Q8Kw5xQTjovtYNO6ImCe3sPyPdo4aQDsMSfHyq8AAA=="
    },
    new Product {
        Id = 10,
        Name = "Artificial Plant Decors",
        Price = 670,
        Rating = 5.0M,
        Category = "plants",
        Stock = 20000,
        ImageUrl = "https://example.com/plantdecor.jpg"
    }
);

   

            // coupon
            new Coupon
            {
                Id = 1,
                Code = "WELCOME10",
                DiscountPercentage = 10,
                // ValidFrom = DateTime.Now,
                // ValidTo = DateTime.Now.AddMonths(6),
                ExpiryDate = DateTime.Now.AddMonths(6),
                // Active = true
            };
            new Coupon
            {
                Id = 2,
                Code = "FESTIVE20",
                DiscountPercentage = 20,
                // ValidFrom = DateTime.Now,
                // ValidTo = DateTime.Now.AddMonths(3),
                ExpiryDate = DateTime.Now.AddMonths(3),
                // Active = true
            };
        }
        
    }
}