﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SecureAppLibrary;

namespace SecureAppTests
{
    [TestClass]
    public class EncryptionTests
    {
        [TestMethod]
        public void Encryption_Decryption_Should_Work()
        {
            string original = "SensitiveData";
            string encrypted = EncryptionHelper.Encrypt(original);
            string decrypted = EncryptionHelper.Decrypt(encrypted);

            Assert.AreEqual(original, decrypted);
        }
    }
}
