namespace SecureAuthApi.Services;

public interface IPasswordService
{
    /// <summary>
    /// Hashes the provided password using BCrypt.
    /// </summary>
    string Hash(string password);

    /// <summary>
    /// Verifies the provided password against a stored hash.
    /// </summary>
    bool Verify(string password, string hash);
}

public class BcryptPasswordService : IPasswordService
{
    public string Hash(string password)
    {
        // Generate a salted BCrypt hash
        return BCrypt.Net.BCrypt.HashPassword(password);
    }

    public bool Verify(string password, string hash)
    {
        // Verify that the entered password matches the stored hash
        return BCrypt.Net.BCrypt.Verify(password, hash);
    }
}
