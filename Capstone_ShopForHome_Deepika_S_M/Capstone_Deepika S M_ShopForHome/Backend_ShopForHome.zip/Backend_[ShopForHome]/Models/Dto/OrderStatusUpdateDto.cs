namespace ShopForHome.Api.Models.Dto
{
    public class OrderStatusUpdateDto
    {
        public string Status { get; set; } = string.Empty;
    }
}
