﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SecureAppLibrary;

namespace SecureAppTests
{
    [TestClass]
    public class UserTests
    {
        [TestMethod]
        public void Register_And_Authenticate_Should_Work()
        {
            var user = new User();
            user.Register("password123");
            Assert.IsTrue(user.Authenticate("password123"));
            Assert.IsFalse(user.Authenticate("wrongpassword"));
        }
    }
}
