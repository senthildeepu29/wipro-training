console.log("Static JS Loaded!");
