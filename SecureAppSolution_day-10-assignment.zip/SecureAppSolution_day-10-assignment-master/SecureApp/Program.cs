﻿using System;
using SecureAppLibrary;

class Program
{
    static void Main()
    {
        try
        {
            Logger.LogInfo("Application started");

            Console.WriteLine("Register a new user");
            Console.Write("Username: ");
            string username = Console.ReadLine();

            Console.Write("Password: ");
            string password = Console.ReadLine();

            var user = new User { Username = username };
            user.Register(password);
            Logger.LogInfo($"User {username} registered.");

            Console.WriteLine("Log in now");
            Console.Write("Password: ");
            string loginPassword = Console.ReadLine();

            if (user.Authenticate(loginPassword))
            {
                Console.WriteLine("Login successful!");
                Logger.LogInfo($"User {username} logged in successfully.");
            }
            else
            {
                Console.WriteLine("Login failed.");
                Logger.LogInfo($"User {username} failed to log in.");
            }

            // Example of encryption
            string sensitive = "MySecretInfo";
            string encrypted = EncryptionHelper.Encrypt(sensitive);
            string decrypted = EncryptionHelper.Decrypt(encrypted);

            Console.WriteLine($"Encrypted: {encrypted}");
            Console.WriteLine($"Decrypted: {decrypted}");
        }
        catch (Exception ex)
        {
            Logger.LogError("Unhandled Exception: " + ex.Message);
        }
    }
}
