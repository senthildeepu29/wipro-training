﻿using Serilog;

namespace SecureAppLibrary
{
    public static class Logger
    {
        static Logger()
        {
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("logs/log.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();
        }

        public static void LogInfo(string message) => Log.Information(message);
        public static void LogError(string message) => Log.Error(message);
    }
}
