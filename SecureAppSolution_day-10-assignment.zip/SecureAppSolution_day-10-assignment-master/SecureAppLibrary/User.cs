﻿using System.Security.Cryptography;
using System.Text;

namespace SecureAppLibrary
{
    public class User
    {
        public string Username { get; set; }
        public string HashedPassword { get; private set; }

        public void Register(string password)
        {
            HashedPassword = HashPassword(password);
        }

        public bool Authenticate(string password)
        {
            return HashedPassword == HashPassword(password);
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hash);
            }
        }
    }
}
