﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace SecureAppTests
{
    [TestClass]
    public class ErrorHandlingTests
    {
        [TestMethod]
        public void Test_Error_Handling_And_Logging()
        {
            try
            {
                throw new InvalidOperationException("Simulated Exception");
            }
            catch (Exception ex)
            {
                SecureAppLibrary.Logger.LogError("Caught: " + ex.Message);
                Assert.IsTrue(true); // just check that it didn't crash
            }
        }
    }
}
