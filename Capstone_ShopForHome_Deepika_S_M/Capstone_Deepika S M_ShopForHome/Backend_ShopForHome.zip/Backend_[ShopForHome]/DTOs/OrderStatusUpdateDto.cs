namespace ShopForHome.Api.Dtos
{
    public class OrderStatusUpdateDto
    {
        public string? Status { get; set; }
    }
}
