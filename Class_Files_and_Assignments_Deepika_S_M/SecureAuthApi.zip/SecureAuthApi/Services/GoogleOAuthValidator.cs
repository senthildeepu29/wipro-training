

namespace SecureAuthApi.Services
{
    public class GoogleOptions
    {
        public string ClientId { get; set; } = default!;
        public string Audience { get; set; } = default!;
    }

    public interface IGoogleOAuthValidator
    {
        /// <summary>
        /// Mock validates the Google OAuth token.
        /// </summary>
        /// <param name="idToken">OAuth token from client.</param>
        /// <returns>Tuple with status, email, and name.</returns>
        Task<(bool ok, string? email, string? name)> ValidateAsync(string idToken);
    }

    public class GoogleOAuthValidator : IGoogleOAuthValidator
    {
        public Task<(bool ok, string? email, string? name)> ValidateAsync(string idToken)
        {
            // ✅ Mock mode: always return success
            return Task.FromResult((true, "google_user@example.com", "Google User"));
        }
    }
}
